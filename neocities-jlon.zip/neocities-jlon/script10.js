window.onload = choosePic;

var myPix = new Array("beyourtruemind.png","smt3.png");

function choosePic() {
     var randomNum = Math.floor(Math.random() * myPix.length);
     document.getElementById("myPicture").src = myPix[randomNum];